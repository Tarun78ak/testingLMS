from django.db import models
import re
#import bcrypt

#EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

# Create your models here.


class EmpManager(models.Manager):
    '''
    def register_validator(self, postData):
        errors = {}
        # Validation Rules for First Name
        if len(postData['username']) < 1:
            errors["username"] = "Username is required"
        # Validation Rules for Password
        if len(postData['password']) < 1:
            errors["password"] = "Password is required"
        elif len(postData['password']) < 8:
            errors["password"] = "Password should be at least 8 characters"

        # Validation Rules for Confirm Password
        if postData['password'] != postData['confirm_password']:
            errors["confirm_password"] = "Password and Password Confirmation did not match"

        return errors
    '''
    def login_validator(self, postData):
        errors = {}
        print("here")
        print(postData['username'])
        auth = Authentications.objects.get(username=postData['username'])
        print(auth.username)
        # Validation Rules for Login Email
        if len(postData['username']) < 1:
            errors["username"] = "Username is required"
        elif not Authentications.objects.get(username=postData['username']):
            errors["username"] = "This account does not exist. Please register."

        # Validation Rules for Login Password
        if len(postData['password']) < 1:
            errors["password"] = "Password is required"
        else:
            auth = Authentications.objects.get(username=postData['username'])

            print(auth)
            # pwhash=bcrypt.hashpw(auth.password.encode('utf8'), bcrypt.gensalt())
            # self.password_hash = pwhash.decode('utf8')
            # if not bcrypt.checkpw(postData['password'].encode(), self.password_hash.encode()):
            #     errors["password"] = "Password is not correct"
            if postData['password'] != auth.password:
                errors["password"] = "Password is not correct"

        return errors

class Authentications(models.Model):
    #    username = models.CharField(max_length=100,primary_key=True)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=16)
    # last_login = models.DateField(auto_now=True)
    role_id = models.IntegerField()

    def __repr__(self):
        return f"<Authentication: {self.username} {self.role_id} >"

    objects = EmpManager()

class Role(models.Model):
    role_id = models.IntegerField(primary_key=True)
    role = models.CharField(max_length=50)

class Employee(models.Model):
    #    username = models.CharField(max_length=100,primary_key=True)
    # ps_no = models.CharField(max_length=10,primary_key=True)
    ps_no = models.CharField(max_length=10)
    first_name = models.CharField(max_length=16)
    last_name = models.CharField(max_length=16)
    dob = models.DateField(max_length=16)
    start_date = models.DateField(auto_now=True)
    leave_count = models.IntegerField()
    manager_ps_no = models.CharField(max_length=10)
    role_id= models.ForeignKey(Role,db_column='role_id', on_delete=models.CASCADE)
    




class Leave(models.Model):
    #    username = models.CharField(max_length=100,primary_key=True)
    # ps_no = models.CharField(max_length=10,foreign_key=True)
    ps_no = models.ForeignKey(Employee,db_column='ps_no', on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    leave_type = models.CharField(max_length=50)
    status = models.IntegerField()
    create_date = models.DateField()
    update_date = models.DateField()

