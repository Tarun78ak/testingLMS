from django.urls import path
from . import views

# urlpatterns = [
#     path('login/', views.LoginView.as_view(), name="Login"),
# ]
app_name="manager"
urlpatterns = [
    path('', views.index,name="index"),
    # path('login', views.login,name="login"),
    path('reset', views.reset, name="reset"),
    path('wall', views.wall , name="wall"),
    path('teamstructure', views.teamstructure, name="teamstructure"),
]
