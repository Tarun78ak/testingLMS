'''
from django.shortcuts import render
from django.views.generic import TemplateView

Create your views here.
class LoginView(TemplateView):
	template_name = 'index.html'

'''


# By Andy Nguyen
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from login.models import Authentications
#import bcrypt

# Create your views here.


def index(request):
    if 'user_id' in request.session:
        return redirect('/manager/wall')
    else:
        return render(request, 'index.html')
'''
def login(request):
    if request.method == "POST":
        errors = Authentications.objects.login_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.add_message(
                    request, messages.ERROR, value, extra_tags='login')
            return redirect('/')
        else:
            auth = Authentications.objects.get(
                username=request.POST['username'])
            request.session['user_id'] = auth.id
            return redirect("/manager/wall")
'''

def wall(request):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        # context = {
        #     "authentication": Authentications.objects.get(id=request.session['user_id'])
        # }
        # # return render(request, 'userpage.html', context)
        # return render(request, 'userpage.html', context)
        # emp=Authentications.objects.get(id=request.session['user_id'])
        emp = Authentications.objects.filter(id=request.session['user_id']).values()

        context = {
            'emp': emp,
        }
        return render(request, 'userpage.html', context)



def reset(request):
    if 'user_id' not in request.session:
        return redirect('/')
    else:
        request.session.clear()
        print("session has been cleared")
        return redirect("/")

